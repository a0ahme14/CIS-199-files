﻿/* R6774, Program 2, 03/05/20, CIS 199-01, This program calculates marginal income tax rate and income tax amount due given a person's income and choice of plan*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //calculate button under which the calculations will occur when clicked
        private void calc_Click(object sender, EventArgs e)
        {
            //defining variables
            int income;
            double amount = 0;

            //reads user input for income
            if (int.TryParse(inc_txt.Text, out income))
            {
                //Cand0 represents baseline plan
                if (cand0.Checked)
                {
                    //defining ranges and rates as constants
                    const int range1 = 9700;
                    const int range2 = 39475;
                    const int range3 = 84200;
                    const int range4 = 160725;
                    const int range5 = 204100;
                    const int range6 = 510300;
                    const double rate1 = .1;
                    const double rate2 = .12;
                    const double rate3 = .22;
                    const double rate4 = .24;
                    const double rate5 = .32;
                    const double rate6 = .35;
                    const double rate7 = .37;

                    //if else statements to display correct rates given remaining income and rates
                    if (income <= range1)
                    {
                        amount = income * rate1;
                        marg_lbl.Text = rate1.ToString("P");
                    }
                    else if (income <= range2)
                    {
                        amount = ((income - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate2.ToString("P");
                    }
                    else if (income <= range3)
                    {
                        amount = ((income - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate3.ToString("P");
                    }
                    else if (income <= range4)
                    {
                        amount = ((income - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate4.ToString("P");
                    }
                    else if (income <= range5)
                    {
                        amount = ((income - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate5.ToString("P");
                    }
                    else if (income <= range6)
                    {
                        amount = ((income - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate6.ToString("P");
                    }
                    else if (income > range6)
                    {
                        amount = ((income - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate7.ToString("P");
                    }
                }
                //Cand1 represents candidate 1's plan
                if (cand1.Checked)
                {
                    //defining ranges and rates as constants
                    const int range1 = 9525;
                    const int range2 = 38700;
                    const int range3 = 82500;
                    const int range4 = 157500;
                    const int range5 = 200000;
                    const int range6 = 500000;
                    const double rate1 = .1;
                    const double rate2 = .15;
                    const double rate3 = .25;
                    const double rate4 = .28;
                    const double rate5 = .33;
                    const double rate6 = .35;
                    const double rate7 = .396;

                    //if else statements to display correct rates given remaining income and rates
                    if (income <= range1)
                    {
                        amount = income * rate1;
                        marg_lbl.Text = rate1.ToString("P");
                    }
                    else if (income <= range2)
                    {
                        amount = ((income - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate2.ToString("P");
                    }
                    else if (income <= range3)
                    {
                        amount = ((income - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate3.ToString("P");
                    }
                    else if (income <= range4)
                    {
                        amount = ((income - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate4.ToString("P");
                    }
                    else if (income <= range5)
                    {
                        amount = ((income - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate5.ToString("P");
                    }
                    else if (income <= range6)
                    {
                        amount = ((income - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate6.ToString("P");
                    }
                    else if (income > range6)
                    {
                        amount = ((income - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate7.ToString("P");
                    }
                }
                //Cand2 represents candidate 2's plan
                if (cand2.Checked)
                {
                    //defining ranges and rates as constants
                    const int range1 = 9525;
                    const int range2 = 38700;
                    const int range3 = 82500;
                    const int range4 = 157500;
                    const int range5 = 200000;
                    const int range6 = 250000;
                    const int range7 = 500000;
                    const int range8 = 2000000;
                    const int range9 = 10000000;
                    const int extraRange = 29000;
                    double extraIncome;
                    const double rate1 = .1;
                    const double rate2 = .12;
                    const double rate3 = .22;
                    const double rate4 = .24;
                    const double rate5 = .32;
                    const double rate6 = .35;
                    const double rate7 = .40;
                    const double rate8 = .45;
                    const double rate9 = .50;
                    const double rate10 = .52;
                    const double extraRate = .04;

                    //if else statements to display correct rates given remaining income and rates
                    if (income <= range1)
                    {
                        amount = income * rate1;
                        marg_lbl.Text = rate1.ToString("P");
                    }
                    else if (income <= range2)
                    {
                        if (income > extraRange)
                        {
                            extraIncome = (income - extraRange) * extraRate;
                            amount = ((income - range1) * rate2) + (range1 * rate1) + extraIncome;
                        }
                        else
                            amount = ((income - range1) * rate2) + (range1 * rate1);
                        marg_lbl.Text = rate2.ToString("P");
                    }
                    else if (income <= range3)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate3.ToString("P");
                    }
                    else if (income <= range4)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate4.ToString("P");
                    }
                    else if (income <= range5)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate5.ToString("P");
                    }
                    else if (income <= range6)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate6.ToString("P");
                    }
                    else if (income <= range7)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate7.ToString("P");
                    }
                    else if (income <= range8)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range6) * rate7) + ((range7 - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate8.ToString("P");
                    }
                    else if (income <= range9)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range6) * rate7) + ((range8 - rate7) * rate8) + ((range7 - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate9.ToString("P");
                    }
                    else if (income > range9)
                    {
                        extraIncome = (income - extraRange) * extraRate;
                        amount = ((income - range6) * rate7) + ((range9 - rate8) * rate9) + ((range7 - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1) + extraIncome;
                        marg_lbl.Text = rate10.ToString("P");
                    }
                }
                //Cand3 represents candidate 3's plan
                if (cand3.Checked)
                {
                    //defining ranges and rates as constants
                    const int range1 = 9525;
                    const int range2 = 38700;
                    const int range3 = 82500;
                    const int range4 = 157500;
                    const int range5 = 200000;
                    const int range6 = 500000;
                    const double deductionRate = .9;
                    const double rate1 = .1;
                    const double rate2 = .15;
                    const double rate3 = .25;
                    const double rate4 = .28;
                    const double rate5 = .33;
                    const double rate6 = .35;
                    const double rate7 = .396;

                    //if else statements to display correct rates given remaining income and rates
                    if (income <= range1)
                    {
                        amount = (income * rate1);
                        amount *= deductionRate;
                        marg_lbl.Text = rate1.ToString("P");
                    }
                    else if (income <= range2)
                    {
                        amount = ((income - range1) * rate2) + (range1 * rate1);
                        amount *= deductionRate;
                        marg_lbl.Text = rate2.ToString("P");
                    }
                    else if (income <= range3)
                    {
                        amount = ((income - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        amount *= deductionRate;
                        marg_lbl.Text = rate3.ToString("P");
                    }
                    else if (income <= range4)
                    {
                        amount = ((income - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        amount *= deductionRate;
                        marg_lbl.Text = rate4.ToString("P");
                    }
                    else if (income <= range5)
                    {
                        amount = ((income - range4) * rate5) + ((range4 - range3) * rate4) + ((range3 - range2) * rate3) + ((range2 - range1) * rate2) + (range1 * rate1);
                        amount *= deductionRate;
                        marg_lbl.Text = rate5.ToString("P");
                    }
                    else if (income <= range6)
                    {
                        amount = ((income - range5) * rate6) + ((range5 - range4) * rate5) * deductionRate + ((range4 - range3) * rate4) * deductionRate + ((range3 - range2) * rate3) * deductionRate + ((range2 - range1) * rate2) * deductionRate + (range1 * rate1) * deductionRate;
                        marg_lbl.Text = rate6.ToString("P");
                    }
                    else if (income > range6)
                    {
                        amount = ((income - range6) * rate7) + ((range6 - range5) * rate6) + ((range5 - range4) * rate5) * deductionRate + ((range4 - range3) * rate4) * deductionRate + ((range3 - range2) * rate3) * deductionRate + ((range2 - range1) * rate2) * deductionRate + (range1 * rate1) * deductionRate;
                        marg_lbl.Text = rate7.ToString("P");
                    }
                }
                //Displays income tax based on user's income and choice of plan
                tax_lbl.Text = amount.ToString("C");
            }
        }
    }
}
