﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inc_lbl = new System.Windows.Forms.Label();
            this.inc_txt = new System.Windows.Forms.TextBox();
            this.plan_lbl = new System.Windows.Forms.Label();
            this.cand0 = new System.Windows.Forms.RadioButton();
            this.cand1 = new System.Windows.Forms.RadioButton();
            this.cand2 = new System.Windows.Forms.RadioButton();
            this.cand3 = new System.Windows.Forms.RadioButton();
            this.calc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.marg_lbl = new System.Windows.Forms.Label();
            this.tax_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inc_lbl
            // 
            this.inc_lbl.AutoSize = true;
            this.inc_lbl.Location = new System.Drawing.Point(52, 49);
            this.inc_lbl.Name = "inc_lbl";
            this.inc_lbl.Size = new System.Drawing.Size(72, 13);
            this.inc_lbl.TabIndex = 0;
            this.inc_lbl.Text = "Enter income:";
            // 
            // inc_txt
            // 
            this.inc_txt.Location = new System.Drawing.Point(131, 46);
            this.inc_txt.Name = "inc_txt";
            this.inc_txt.Size = new System.Drawing.Size(100, 20);
            this.inc_txt.TabIndex = 1;
            // 
            // plan_lbl
            // 
            this.plan_lbl.AutoSize = true;
            this.plan_lbl.Location = new System.Drawing.Point(55, 84);
            this.plan_lbl.Name = "plan_lbl";
            this.plan_lbl.Size = new System.Drawing.Size(72, 13);
            this.plan_lbl.TabIndex = 2;
            this.plan_lbl.Text = "Choose plan: ";
            // 
            // cand0
            // 
            this.cand0.AutoSize = true;
            this.cand0.Location = new System.Drawing.Point(131, 84);
            this.cand0.Name = "cand0";
            this.cand0.Size = new System.Drawing.Size(65, 17);
            this.cand0.TabIndex = 3;
            this.cand0.TabStop = true;
            this.cand0.Text = "Baseline";
            this.cand0.UseVisualStyleBackColor = true;
            // 
            // cand1
            // 
            this.cand1.AutoSize = true;
            this.cand1.Location = new System.Drawing.Point(131, 108);
            this.cand1.Name = "cand1";
            this.cand1.Size = new System.Drawing.Size(82, 17);
            this.cand1.TabIndex = 4;
            this.cand1.TabStop = true;
            this.cand1.Text = "Candidate 1";
            this.cand1.UseVisualStyleBackColor = true;
            // 
            // cand2
            // 
            this.cand2.AutoSize = true;
            this.cand2.Location = new System.Drawing.Point(131, 132);
            this.cand2.Name = "cand2";
            this.cand2.Size = new System.Drawing.Size(82, 17);
            this.cand2.TabIndex = 5;
            this.cand2.TabStop = true;
            this.cand2.Text = "Candidate 2";
            this.cand2.UseVisualStyleBackColor = true;
            // 
            // cand3
            // 
            this.cand3.AutoSize = true;
            this.cand3.Location = new System.Drawing.Point(131, 156);
            this.cand3.Name = "cand3";
            this.cand3.Size = new System.Drawing.Size(82, 17);
            this.cand3.TabIndex = 6;
            this.cand3.TabStop = true;
            this.cand3.Text = "Candidate 3";
            this.cand3.UseVisualStyleBackColor = true;
            // 
            // calc
            // 
            this.calc.Location = new System.Drawing.Point(155, 216);
            this.calc.Name = "calc";
            this.calc.Size = new System.Drawing.Size(75, 23);
            this.calc.TabIndex = 7;
            this.calc.Text = "Calculate Tax";
            this.calc.UseVisualStyleBackColor = true;
            this.calc.Click += new System.EventHandler(this.calc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 263);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Marginal Tax Rate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 293);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Income Tax:";
            // 
            // marg_lbl
            // 
            this.marg_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.marg_lbl.Location = new System.Drawing.Point(131, 262);
            this.marg_lbl.Name = "marg_lbl";
            this.marg_lbl.Size = new System.Drawing.Size(100, 20);
            this.marg_lbl.TabIndex = 10;
            // 
            // tax_lbl
            // 
            this.tax_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tax_lbl.Location = new System.Drawing.Point(131, 293);
            this.tax_lbl.Name = "tax_lbl";
            this.tax_lbl.Size = new System.Drawing.Size(100, 20);
            this.tax_lbl.TabIndex = 11;
            // 
            // Form1
            // 
            this.AcceptButton = this.calc;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tax_lbl);
            this.Controls.Add(this.marg_lbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calc);
            this.Controls.Add(this.cand3);
            this.Controls.Add(this.cand2);
            this.Controls.Add(this.cand1);
            this.Controls.Add(this.cand0);
            this.Controls.Add(this.plan_lbl);
            this.Controls.Add(this.inc_txt);
            this.Controls.Add(this.inc_lbl);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inc_lbl;
        private System.Windows.Forms.TextBox inc_txt;
        private System.Windows.Forms.Label plan_lbl;
        private System.Windows.Forms.RadioButton cand0;
        private System.Windows.Forms.RadioButton cand1;
        private System.Windows.Forms.RadioButton cand2;
        private System.Windows.Forms.RadioButton cand3;
        private System.Windows.Forms.Button calc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label marg_lbl;
        private System.Windows.Forms.Label tax_lbl;
    }
}

