﻿/* R6774, Lab 4, 02/16/20, CIS 199-01, This program  checks students'GPA and Test score 
 * then provides an admission decision. It also keeps a running total*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Setting running totals
        int AcceptCount = 0;
        int RejectCount = 0;

        //Checks GPA and Test score and displays admission decision
        private void decision_lbl_Click(object sender, EventArgs e)
        {
            //Defining unknowns
            float gpa_lbl;
            double test_lbl;

            //Setting constants for grades
            const int gpa_result = 3;
            const int score_high = 80;
            const int score_low = 60;

            //Gathers user input
            gpa_lbl = float.Parse(gpa_txt.Text);
            test_lbl = double.Parse(test_txt.Text);

            if (float.TryParse(gpa_txt.Text, out gpa_lbl) && gpa_lbl>=0 && gpa_lbl<=4)// Makes sure GPA is between 0 and 4
            {
                if (double.TryParse(test_txt.Text, out test_lbl) && test_lbl>=0 && test_lbl<=100)// Makes sure score is between 0 and 100
                {
                    if (gpa_lbl >= gpa_result && test_lbl >= score_low || gpa_lbl < gpa_result && test_lbl >= score_high)// Decides if student meets criteria
                    {
                        // Shows decision and counts accepted students
                        decision_txt.Text = "Accept";
                        AcceptCount += 1;
                        accept_count.Text = AcceptCount.ToString();
                    }

                    else 
                    {
                        // Shows decision and counts rejected students
                        decision_txt.Text = "Reject";
                        RejectCount += 1;
                        reject_count.Text = RejectCount.ToString();
                    }
                    
                }
                else
                    //Asks user to correct their input if it's wrong
                    MessageBox.Show("Enter a valid score");
            }


            else
                //Asks user to correct their input if it's wrong
                MessageBox.Show("Enter a valid GPA");

        }

        private void accept_count_Click(object sender, EventArgs e)
        {

        }
    }
}
