﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpa_lbl = new System.Windows.Forms.Label();
            this.gpa_txt = new System.Windows.Forms.TextBox();
            this.test_lbl = new System.Windows.Forms.Label();
            this.test_txt = new System.Windows.Forms.TextBox();
            this.decision_txt = new System.Windows.Forms.Label();
            this.decision_lbl = new System.Windows.Forms.Button();
            this.accept_count = new System.Windows.Forms.Label();
            this.reject_count = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpa_lbl
            // 
            this.gpa_lbl.AutoSize = true;
            this.gpa_lbl.Location = new System.Drawing.Point(96, 57);
            this.gpa_lbl.Name = "gpa_lbl";
            this.gpa_lbl.Size = new System.Drawing.Size(57, 13);
            this.gpa_lbl.TabIndex = 0;
            this.gpa_lbl.Text = "Enter GPA";
            // 
            // gpa_txt
            // 
            this.gpa_txt.Location = new System.Drawing.Point(193, 54);
            this.gpa_txt.Name = "gpa_txt";
            this.gpa_txt.Size = new System.Drawing.Size(100, 20);
            this.gpa_txt.TabIndex = 1;
            // 
            // test_lbl
            // 
            this.test_lbl.AutoSize = true;
            this.test_lbl.Location = new System.Drawing.Point(66, 106);
            this.test_lbl.Name = "test_lbl";
            this.test_lbl.Size = new System.Drawing.Size(87, 13);
            this.test_lbl.TabIndex = 2;
            this.test_lbl.Text = "Enter Test Score";
            // 
            // test_txt
            // 
            this.test_txt.Location = new System.Drawing.Point(193, 103);
            this.test_txt.Name = "test_txt";
            this.test_txt.Size = new System.Drawing.Size(100, 20);
            this.test_txt.TabIndex = 3;
            // 
            // decision_txt
            // 
            this.decision_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.decision_txt.Location = new System.Drawing.Point(193, 153);
            this.decision_txt.Name = "decision_txt";
            this.decision_txt.Size = new System.Drawing.Size(97, 23);
            this.decision_txt.TabIndex = 5;
            // 
            // decision_lbl
            // 
            this.decision_lbl.Location = new System.Drawing.Point(56, 153);
            this.decision_lbl.Name = "decision_lbl";
            this.decision_lbl.Size = new System.Drawing.Size(97, 23);
            this.decision_lbl.TabIndex = 6;
            this.decision_lbl.Text = "Accept/Reject";
            this.decision_lbl.UseVisualStyleBackColor = true;
            this.decision_lbl.Click += new System.EventHandler(this.decision_lbl_Click);
            // 
            // accept_count
            // 
            this.accept_count.AutoSize = true;
            this.accept_count.Location = new System.Drawing.Point(490, 54);
            this.accept_count.Name = "accept_count";
            this.accept_count.Size = new System.Drawing.Size(13, 13);
            this.accept_count.TabIndex = 7;
            this.accept_count.Text = "0";
            this.accept_count.Click += new System.EventHandler(this.accept_count_Click);
            // 
            // reject_count
            // 
            this.reject_count.AutoSize = true;
            this.reject_count.Location = new System.Drawing.Point(490, 103);
            this.reject_count.Name = "reject_count";
            this.reject_count.Size = new System.Drawing.Size(13, 13);
            this.reject_count.TabIndex = 8;
            this.reject_count.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(428, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Accepted:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Rejected:";
            // 
            // Form1
            // 
            this.AcceptButton = this.decision_lbl;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reject_count);
            this.Controls.Add(this.accept_count);
            this.Controls.Add(this.decision_lbl);
            this.Controls.Add(this.decision_txt);
            this.Controls.Add(this.test_txt);
            this.Controls.Add(this.test_lbl);
            this.Controls.Add(this.gpa_txt);
            this.Controls.Add(this.gpa_lbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpa_lbl;
        private System.Windows.Forms.TextBox gpa_txt;
        private System.Windows.Forms.Label test_lbl;
        private System.Windows.Forms.TextBox test_txt;
        private System.Windows.Forms.Label decision_txt;
        private System.Windows.Forms.Button decision_lbl;
        private System.Windows.Forms.Label accept_count;
        private System.Windows.Forms.Label reject_count;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

