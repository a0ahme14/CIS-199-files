﻿/* R6774, Program 1, 02/11/20, CIS 199-01, This program calculates material and labor costs for a carpet sales and installation company.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void width_lbl_Click(object sender, EventArgs e)
        {

        }
        // Calculate and display area and costs.
        private void Calculate_Click(object sender, EventArgs e)
        {
            // User's input
            double width_lbl;       //room's width
            double length_lbl;      //room's length
            double carpet_lbl;      //carpet's price
            int layers_lbl;         //layers needed
            int firstroom_lbl;      // first room or not

            double yards_lbl;       // Area in Sq. yards
            double carpetcost_lbl;  // Carpet cost
            double paddingcost_lbl; // Padding cost
            double laborcost_lbl;   // Labor cost
            double total_lbl;       // Sum of costs

            const double extra_charge = 75;
            const double waste = .10;

            // Gathering user's input
            width_lbl = double.Parse(width_txt.Text);
            length_lbl = double.Parse(length_txt.Text);
            carpet_lbl = double.Parse(carpet_txt.Text);
            layers_lbl = int.Parse(layers_txt.Text);
            firstroom_lbl = Convert.ToInt32(firstroom_txt.Text);

            // Calculate area and costs
            yards_lbl = width_lbl * length_lbl / 9.0;
            carpetcost_lbl = carpet_lbl * (yards_lbl + waste * yards_lbl) ;
            paddingcost_lbl = 2.5 * ( layers_lbl * yards_lbl + waste * layers_lbl * yards_lbl);

            // Deciding whether to charge the extra 75 dollars or not
            if (firstroom_lbl > 0)
                laborcost_lbl = 4.25 * yards_lbl + extra_charge;
            else
                laborcost_lbl = 4.25 * yards_lbl;

            // Sums up the total
            total_lbl = carpetcost_lbl + paddingcost_lbl + laborcost_lbl;

            // Output data to labels 
            yards_txt.Text = $"{yards_lbl:F1}";
            carpetcost_txt.Text = $"{carpetcost_lbl:C2}";
            paddingcost_txt.Text = $"{paddingcost_lbl:C2}";
            laborcost_txt.Text = $"{laborcost_lbl:C2}";
            total_txt.Text = $"{total_lbl:C2}";

        }
    }
}
