﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.width_lbl = new System.Windows.Forms.Label();
            this.length_lbl = new System.Windows.Forms.Label();
            this.carpet_lbl = new System.Windows.Forms.Label();
            this.width_txt = new System.Windows.Forms.TextBox();
            this.length_txt = new System.Windows.Forms.TextBox();
            this.carpet_txt = new System.Windows.Forms.TextBox();
            this.layers_lbl = new System.Windows.Forms.Label();
            this.layers_txt = new System.Windows.Forms.TextBox();
            this.firstroom_lbl = new System.Windows.Forms.Label();
            this.firstroom_txt = new System.Windows.Forms.TextBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.yards_lbl = new System.Windows.Forms.Label();
            this.carpetcost_lbl = new System.Windows.Forms.Label();
            this.paddingcost_lbl = new System.Windows.Forms.Label();
            this.laborcost_lbl = new System.Windows.Forms.Label();
            this.Total_lbl = new System.Windows.Forms.Label();
            this.yards_txt = new System.Windows.Forms.Label();
            this.carpetcost_txt = new System.Windows.Forms.Label();
            this.paddingcost_txt = new System.Windows.Forms.Label();
            this.laborcost_txt = new System.Windows.Forms.Label();
            this.total_txt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // width_lbl
            // 
            this.width_lbl.AutoSize = true;
            this.width_lbl.Location = new System.Drawing.Point(78, 56);
            this.width_lbl.Name = "width_lbl";
            this.width_lbl.Size = new System.Drawing.Size(66, 13);
            this.width_lbl.TabIndex = 0;
            this.width_lbl.Text = "Room width:";
            this.width_lbl.Click += new System.EventHandler(this.width_lbl_Click);
            // 
            // length_lbl
            // 
            this.length_lbl.AutoSize = true;
            this.length_lbl.Location = new System.Drawing.Point(74, 81);
            this.length_lbl.Name = "length_lbl";
            this.length_lbl.Size = new System.Drawing.Size(70, 13);
            this.length_lbl.TabIndex = 1;
            this.length_lbl.Text = "Room length:";
            this.length_lbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // carpet_lbl
            // 
            this.carpet_lbl.AutoSize = true;
            this.carpet_lbl.Location = new System.Drawing.Point(77, 109);
            this.carpet_lbl.Name = "carpet_lbl";
            this.carpet_lbl.Size = new System.Drawing.Size(67, 13);
            this.carpet_lbl.TabIndex = 2;
            this.carpet_lbl.Text = "Carpet price:";
            // 
            // width_txt
            // 
            this.width_txt.Location = new System.Drawing.Point(150, 50);
            this.width_txt.Name = "width_txt";
            this.width_txt.Size = new System.Drawing.Size(100, 20);
            this.width_txt.TabIndex = 3;
            // 
            // length_txt
            // 
            this.length_txt.Location = new System.Drawing.Point(150, 75);
            this.length_txt.Name = "length_txt";
            this.length_txt.Size = new System.Drawing.Size(100, 20);
            this.length_txt.TabIndex = 4;
            // 
            // carpet_txt
            // 
            this.carpet_txt.Location = new System.Drawing.Point(150, 103);
            this.carpet_txt.Name = "carpet_txt";
            this.carpet_txt.Size = new System.Drawing.Size(100, 20);
            this.carpet_txt.TabIndex = 5;
            // 
            // layers_lbl
            // 
            this.layers_lbl.AutoSize = true;
            this.layers_lbl.Location = new System.Drawing.Point(14, 138);
            this.layers_lbl.Name = "layers_lbl";
            this.layers_lbl.Size = new System.Drawing.Size(130, 13);
            this.layers_lbl.TabIndex = 6;
            this.layers_lbl.Text = "Layers of padding (1 or 2):";
            this.layers_lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // layers_txt
            // 
            this.layers_txt.Location = new System.Drawing.Point(150, 135);
            this.layers_txt.Name = "layers_txt";
            this.layers_txt.Size = new System.Drawing.Size(100, 20);
            this.layers_txt.TabIndex = 7;
            // 
            // firstroom_lbl
            // 
            this.firstroom_lbl.AutoSize = true;
            this.firstroom_lbl.Location = new System.Drawing.Point(14, 169);
            this.firstroom_lbl.Name = "firstroom_lbl";
            this.firstroom_lbl.Size = new System.Drawing.Size(134, 13);
            this.firstroom_lbl.TabIndex = 8;
            this.firstroom_lbl.Text = "First room? (1=Yes | 0=No):";
            // 
            // firstroom_txt
            // 
            this.firstroom_txt.Location = new System.Drawing.Point(150, 163);
            this.firstroom_txt.Name = "firstroom_txt";
            this.firstroom_txt.Size = new System.Drawing.Size(100, 20);
            this.firstroom_txt.TabIndex = 9;
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(355, 379);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(75, 23);
            this.Calculate.TabIndex = 10;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // yards_lbl
            // 
            this.yards_lbl.AutoSize = true;
            this.yards_lbl.Location = new System.Drawing.Point(44, 224);
            this.yards_lbl.Name = "yards_lbl";
            this.yards_lbl.Size = new System.Drawing.Size(97, 13);
            this.yards_lbl.TabIndex = 11;
            this.yards_lbl.Text = "Sq. Yards Needed:";
            // 
            // carpetcost_lbl
            // 
            this.carpetcost_lbl.AutoSize = true;
            this.carpetcost_lbl.Location = new System.Drawing.Point(76, 252);
            this.carpetcost_lbl.Name = "carpetcost_lbl";
            this.carpetcost_lbl.Size = new System.Drawing.Size(65, 13);
            this.carpetcost_lbl.TabIndex = 12;
            this.carpetcost_lbl.Text = "Carpet Cost:";
            // 
            // paddingcost_lbl
            // 
            this.paddingcost_lbl.AutoSize = true;
            this.paddingcost_lbl.Location = new System.Drawing.Point(68, 280);
            this.paddingcost_lbl.Name = "paddingcost_lbl";
            this.paddingcost_lbl.Size = new System.Drawing.Size(73, 13);
            this.paddingcost_lbl.TabIndex = 13;
            this.paddingcost_lbl.Text = "Padding Cost:";
            // 
            // laborcost_lbl
            // 
            this.laborcost_lbl.AutoSize = true;
            this.laborcost_lbl.Location = new System.Drawing.Point(80, 306);
            this.laborcost_lbl.Name = "laborcost_lbl";
            this.laborcost_lbl.Size = new System.Drawing.Size(61, 13);
            this.laborcost_lbl.TabIndex = 14;
            this.laborcost_lbl.Text = "Labor Cost:";
            // 
            // Total_lbl
            // 
            this.Total_lbl.AutoSize = true;
            this.Total_lbl.Location = new System.Drawing.Point(83, 333);
            this.Total_lbl.Name = "Total_lbl";
            this.Total_lbl.Size = new System.Drawing.Size(58, 13);
            this.Total_lbl.TabIndex = 15;
            this.Total_lbl.Text = "Total Cost:";
            // 
            // yards_txt
            // 
            this.yards_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yards_txt.Location = new System.Drawing.Point(150, 220);
            this.yards_txt.Name = "yards_txt";
            this.yards_txt.Size = new System.Drawing.Size(100, 20);
            this.yards_txt.TabIndex = 16;
            // 
            // carpetcost_txt
            // 
            this.carpetcost_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carpetcost_txt.Location = new System.Drawing.Point(150, 248);
            this.carpetcost_txt.Name = "carpetcost_txt";
            this.carpetcost_txt.Size = new System.Drawing.Size(100, 20);
            this.carpetcost_txt.TabIndex = 17;
            // 
            // paddingcost_txt
            // 
            this.paddingcost_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paddingcost_txt.Location = new System.Drawing.Point(150, 276);
            this.paddingcost_txt.Name = "paddingcost_txt";
            this.paddingcost_txt.Size = new System.Drawing.Size(100, 20);
            this.paddingcost_txt.TabIndex = 18;
            // 
            // laborcost_txt
            // 
            this.laborcost_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborcost_txt.Location = new System.Drawing.Point(150, 302);
            this.laborcost_txt.Name = "laborcost_txt";
            this.laborcost_txt.Size = new System.Drawing.Size(100, 20);
            this.laborcost_txt.TabIndex = 19;
            // 
            // total_txt
            // 
            this.total_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.total_txt.Location = new System.Drawing.Point(150, 329);
            this.total_txt.Name = "total_txt";
            this.total_txt.Size = new System.Drawing.Size(100, 20);
            this.total_txt.TabIndex = 20;
            // 
            // Form1
            // 
            this.AcceptButton = this.Calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.total_txt);
            this.Controls.Add(this.laborcost_txt);
            this.Controls.Add(this.paddingcost_txt);
            this.Controls.Add(this.carpetcost_txt);
            this.Controls.Add(this.yards_txt);
            this.Controls.Add(this.Total_lbl);
            this.Controls.Add(this.laborcost_lbl);
            this.Controls.Add(this.paddingcost_lbl);
            this.Controls.Add(this.carpetcost_lbl);
            this.Controls.Add(this.yards_lbl);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.firstroom_txt);
            this.Controls.Add(this.firstroom_lbl);
            this.Controls.Add(this.layers_txt);
            this.Controls.Add(this.layers_lbl);
            this.Controls.Add(this.carpet_txt);
            this.Controls.Add(this.length_txt);
            this.Controls.Add(this.width_txt);
            this.Controls.Add(this.carpet_lbl);
            this.Controls.Add(this.length_lbl);
            this.Controls.Add(this.width_lbl);
            this.Name = "Form1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label width_lbl;
        private System.Windows.Forms.Label length_lbl;
        private System.Windows.Forms.Label carpet_lbl;
        private System.Windows.Forms.TextBox width_txt;
        private System.Windows.Forms.TextBox length_txt;
        private System.Windows.Forms.TextBox carpet_txt;
        private System.Windows.Forms.Label layers_lbl;
        private System.Windows.Forms.TextBox layers_txt;
        private System.Windows.Forms.Label firstroom_lbl;
        private System.Windows.Forms.TextBox firstroom_txt;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Label yards_lbl;
        private System.Windows.Forms.Label carpetcost_lbl;
        private System.Windows.Forms.Label paddingcost_lbl;
        private System.Windows.Forms.Label laborcost_lbl;
        private System.Windows.Forms.Label Total_lbl;
        private System.Windows.Forms.Label yards_txt;
        private System.Windows.Forms.Label carpetcost_txt;
        private System.Windows.Forms.Label paddingcost_txt;
        private System.Windows.Forms.Label laborcost_txt;
        private System.Windows.Forms.Label total_txt;
    }
}

