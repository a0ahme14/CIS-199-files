﻿/* R6774, Lab 2, 02/02/20, CIS 199, This program calculates certain tip percentages when given a meal price.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1; //This represents the meal price that the user will enter.

            double tip1; //This is the 15% tip
            double tip2; //This is the 18% tip
            double tip3; //This is the 20% tip

            const double TIPRATE1 = .15; // Assigning named constants.
            const double TIPRATE2 = .18;
            const double TIPRATE3 = .20;

            num1 = double.Parse(textBox1.Text);
            
            tip1 = num1 * TIPRATE1; //This will multiply the price by 15%
            tip2 = num1 * TIPRATE2; //This will multiply the price by 18%
            tip3 = num1 * TIPRATE3; //This will multiply the price by 20%

            label5.Text = $"${tip1:F2}"; //This will displavy the tip amount in currency format with 2 decimal points
            label6.Text = $"${tip2:F2}"; //This will displavy the tip amount in currency format with 2 decimal points
            label7.Text = $"${tip3:F2}"; //This will displavy the tip amount in currency format with 2 decimal points
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }
    }
}
