﻿namespace Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rad_lbl = new System.Windows.Forms.Label();
            this.rad_txt = new System.Windows.Forms.TextBox();
            this.dia_lbl = new System.Windows.Forms.Label();
            this.sur_lbl = new System.Windows.Forms.Label();
            this.vol_lbl = new System.Windows.Forms.Label();
            this.dia_txt = new System.Windows.Forms.Label();
            this.sur_txt = new System.Windows.Forms.Label();
            this.vol_txt = new System.Windows.Forms.Label();
            this.Calculate = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // rad_lbl
            // 
            this.rad_lbl.AutoSize = true;
            this.rad_lbl.Location = new System.Drawing.Point(177, 50);
            this.rad_lbl.Name = "rad_lbl";
            this.rad_lbl.Size = new System.Drawing.Size(92, 13);
            this.rad_lbl.TabIndex = 0;
            this.rad_lbl.Text = "Radius of Sphere:";
            // 
            // rad_txt
            // 
            this.rad_txt.Location = new System.Drawing.Point(276, 47);
            this.rad_txt.Name = "rad_txt";
            this.rad_txt.Size = new System.Drawing.Size(100, 20);
            this.rad_txt.TabIndex = 1;
            // 
            // dia_lbl
            // 
            this.dia_lbl.AutoSize = true;
            this.dia_lbl.Location = new System.Drawing.Point(44, 192);
            this.dia_lbl.Name = "dia_lbl";
            this.dia_lbl.Size = new System.Drawing.Size(49, 13);
            this.dia_lbl.TabIndex = 2;
            this.dia_lbl.Text = "Diameter";
            // 
            // sur_lbl
            // 
            this.sur_lbl.AutoSize = true;
            this.sur_lbl.Location = new System.Drawing.Point(24, 243);
            this.sur_lbl.Name = "sur_lbl";
            this.sur_lbl.Size = new System.Drawing.Size(69, 13);
            this.sur_lbl.TabIndex = 3;
            this.sur_lbl.Text = "Surface Area";
            // 
            // vol_lbl
            // 
            this.vol_lbl.AutoSize = true;
            this.vol_lbl.Location = new System.Drawing.Point(51, 289);
            this.vol_lbl.Name = "vol_lbl";
            this.vol_lbl.Size = new System.Drawing.Size(42, 13);
            this.vol_lbl.TabIndex = 4;
            this.vol_lbl.Text = "Volume";
            // 
            // dia_txt
            // 
            this.dia_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dia_txt.Location = new System.Drawing.Point(115, 192);
            this.dia_txt.Name = "dia_txt";
            this.dia_txt.Size = new System.Drawing.Size(100, 23);
            this.dia_txt.TabIndex = 5;
            // 
            // sur_txt
            // 
            this.sur_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sur_txt.Location = new System.Drawing.Point(118, 243);
            this.sur_txt.Name = "sur_txt";
            this.sur_txt.Size = new System.Drawing.Size(100, 23);
            this.sur_txt.TabIndex = 6;
            // 
            // vol_txt
            // 
            this.vol_txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vol_txt.Location = new System.Drawing.Point(118, 289);
            this.vol_txt.Name = "vol_txt";
            this.vol_txt.Size = new System.Drawing.Size(100, 23);
            this.vol_txt.TabIndex = 7;
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(287, 86);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(75, 23);
            this.Calculate.TabIndex = 8;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(226, 183);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(150, 150);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.Calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.vol_txt);
            this.Controls.Add(this.sur_txt);
            this.Controls.Add(this.dia_txt);
            this.Controls.Add(this.vol_lbl);
            this.Controls.Add(this.sur_lbl);
            this.Controls.Add(this.dia_lbl);
            this.Controls.Add(this.rad_txt);
            this.Controls.Add(this.rad_lbl);
            this.Name = "Form1";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rad_lbl;
        private System.Windows.Forms.TextBox rad_txt;
        private System.Windows.Forms.Label dia_lbl;
        private System.Windows.Forms.Label sur_lbl;
        private System.Windows.Forms.Label vol_lbl;
        private System.Windows.Forms.Label dia_txt;
        private System.Windows.Forms.Label sur_txt;
        private System.Windows.Forms.Label vol_txt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Calculate;
    }
}

