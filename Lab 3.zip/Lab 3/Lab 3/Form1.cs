﻿/* R6774, Lab 3, 02/09/20, CIS 199-01, This program calculates Diameter, Area, and Volume when given the radius*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {   
            // Defining variables
            double rad_lbl;

            double dia_lbl;
            double sur_lbl;
            double vol_lbl;

            // Named constants to be used in calculations
            const double two = 2;
            const double three = 3;
            const double diaformula = 2;
            const double surformula = 4 * Math.PI;
            const double volformula = 1.33333333333 * Math.PI;

            //User input to be read as the radius label
            rad_lbl = double.Parse(rad_txt.Text);

            // calculating the requested information
            dia_lbl = diaformula * rad_lbl;
            sur_lbl = surformula * Math.Pow(rad_lbl, two);
            vol_lbl = volformula * Math.Pow(rad_lbl, three);

            // Displaying the results
            dia_txt.Text = $"{dia_lbl:F2}";
            sur_txt.Text = $"{sur_lbl:F2}";
            vol_txt.Text = $"{vol_lbl:F2}";
        }
    }
}
